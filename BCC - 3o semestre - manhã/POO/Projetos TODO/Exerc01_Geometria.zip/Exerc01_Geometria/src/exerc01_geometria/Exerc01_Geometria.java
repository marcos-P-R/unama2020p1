
package exerc01_geometria;

public class Exerc01_Geometria {
    
    // TODO 1 crie um pacote chamado dimensao
    // TODO 2 dentro do pacote dimensao, crie outro pacote chamado bidimensional
    // TODO 3 dentro do pacote dimensao.bidimensional, crie a classe TrianguloRetangulo
    
    ///////////// FAÇA DENTRO DA CLASSE TrianguloRetangulo:
    ///////////// Sempre usando o modificador de acesso default para a classe, 
    ///////////// atributos e métodos
    // TODO 4 remova o "public" de "public class TrianguloRetangulo"
    // TODO 5 declare o atributo cateto1 
    // TODO 6 declare o atributo cateto2 
    // TODO 7 declare o atributo hipotenusa 
    // TODO 8 declare o atributo alturaHipotenusa 
    // TODO 9 crie um método para calcular e retornar a área do triângulo
    // TODO 10 crie um método para calcular e retornar o perímetro do triângulo
    // TODO 11 crie o contrutor padrão (vazio) e o parametrizado da classe (dica: Alt+Insert)
    //////////////////////////////////////////////

    public static void main(String[] args) {
        // TODO 12 crie aqui um objeto da classe TrianguloRetangulo
        // TODO 13 escreva como comentário: por que aconteceu um erro na criação do objeto?
        // TODO 14 escreva como comentário: o que pode ser feito para resolver o erro?
        // TODO 15 altere o modificador da classe TrianguloRetangulo para public
        // TODO 16 escreva como comentário: por que o erro continua?
        // TODO 17 adicione a importação da classe TrianguloRetangulo (clique na lâmpada ao lado)
        
        // TODO 18 através do objeto, atribua valor dentro dos atributos diretamente
        // TODO 19 escreva como comentário: é possível realizar esta atribuição? Justifique.
        // TODO 20 escreva como comentário: o que pode ser feito para resolver este problema?
        
    }
    
}
