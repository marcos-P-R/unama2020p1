
package cadastroclientes;

import edu.unama.entidades.Cliente;

public class CadastroClientes {

    public static void main(String[] args) {
        Cliente c = new Cliente();
    }
    
}
